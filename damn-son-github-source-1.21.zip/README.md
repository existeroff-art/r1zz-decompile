# Lumina (Fabric 1.21, single-player)

## Build
Requirements: JDK 21 and Gradle 8.8+ (or open the folder in IntelliJ and let it import the Gradle project).

    gradle build

The mod jar is created at `build/libs/lumina-1.0.0.jar`.
Drop it in `.minecraft/mods` together with **Fabric API 0.102.0+1.21** and Fabric Loader 0.16+.

## Use
- **Right Shift** opens the menu (rebindable in Controls -> Lumina).
- Click a module to open its settings, click the switch (or right-click) to toggle it.
- Mode pills: left click = next, right click = previous.
- Keybind row inside each module: click, then press a key (Esc/Backspace clears).
- Accent colors and panel opacity live in Util -> Theme.
- Config is stored in `.minecraft/config/lumina.json`.
- The frosted-glass backdrop uses vanilla's menu blur: Options -> Video Settings -> Menu Background Blur.


## Updated modules and limitations

- **GUI scrolling:** the list and settings scrollbars can be clicked with left mouse to jump and right mouse to page, and dragged without using the wheel.
- **AnchorMacro:** `Trigger = Manual Place` watches an uncharged respawn anchor under the crosshair, charges it with glowstone, then attempts detonation. Anchors do not explode in the Nether; the feature intentionally does nothing there. `Auto Target` preserves the target-placement workflow.
- **CrystalMacro:** validates the two-block crystal space and waits briefly for server entity updates before giving up. The server still decides whether a placement or attack is legal.
- **Fast Gapple:** the in-client timer assist now applies only to golden apples, not all food/potions. For actual accelerated consumption on multiplayer, install the official [Fast Gapple](https://modrinth.com/mod/fast-gapple) mod on both the client and the server where allowed; a client-only mod cannot force a server to accept a shorter eating duration. This project does not redistribute the external mod (its Modrinth listing is ARR).
- **Snap Tap:** added as a client-side module and supports remapped movement keys. It alters client movement input; it does not bypass server rules or anti-cheat. Check the server's rules before using it.
- **Mace Swap:** switches to a hotbar mace while descending past the configured fall distance and can restore the old slot on landing.
- **Mace Windcharge:** after a wind-charge stack is consumed from the selected slot, switches to the hotbar mace; it does not aim or fire the wind charge for you.

The supplied YouTube pages could not be fetched in this environment, so this update does not claim to reproduce every module shown in those videos. The explicit requests above were implemented directly; send a timestamped module list or screenshots for an exact video-by-video match.

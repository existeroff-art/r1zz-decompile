package dev.lumina;

import com.google.gson.*;
import dev.lumina.module.Mod;
import dev.lumina.module.ModuleManager;
import dev.lumina.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("lumina.json");

    private Config() {}

    public static void save(ModuleManager mm) {
        try {
            JsonObject root = new JsonObject();
            for (Mod m : mm.all) {
                JsonObject o = new JsonObject();
                o.addProperty("key", m.key);
                if (m.persistEnabled) o.addProperty("enabled", m.enabled);
                JsonObject ss = new JsonObject();
                for (Setting s : m.settings) ss.add(s.name, s.save());
                o.add("settings", ss);
                root.add(m.name, o);
            }
            Files.writeString(FILE, GSON.toJson(root));
        } catch (Exception e) {
            LuminaClient.LOGGER.error("Could not save config", e);
        }
    }

    public static void load(ModuleManager mm) {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Mod m : mm.all) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (m.persistEnabled && o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                if (o.has("settings")) {
                    JsonObject ss = o.getAsJsonObject("settings");
                    for (Setting s : m.settings) if (ss.has(s.name)) s.load(ss.get(s.name));
                }
            }
        } catch (Exception e) {
            LuminaClient.LOGGER.error("Could not load config", e);
        }
    }
}

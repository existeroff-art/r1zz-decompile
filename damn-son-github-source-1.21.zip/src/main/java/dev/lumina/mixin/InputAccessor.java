package dev.lumina.mixin;

import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Input.class)
public interface InputAccessor {
    @Accessor("movementSideways") void lumina$setMovementSideways(float value);
    @Accessor("movementForward") void lumina$setMovementForward(float value);
}

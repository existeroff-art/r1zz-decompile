package dev.lumina.mixin;

import dev.lumina.module.movement.SnapTap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void lumina$applySnapTap(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        if (!SnapTap.active()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;
        boolean left = client.options.leftKey.isPressed();
        boolean right = client.options.rightKey.isPressed();
        boolean forward = client.options.forwardKey.isPressed();
        boolean back = client.options.backKey.isPressed();
        if (left && right) {
            if (SnapTap.leftWins()) right = false; else left = false;
        }
        if (forward && back) {
            if (SnapTap.forwardWins()) back = false; else forward = false;
        }
        InputAccessor accessor = (InputAccessor) (Object) this;
        accessor.lumina$setMovementSideways(left == right ? 0.0F : (left ? 1.0F : -1.0F));
        accessor.lumina$setMovementForward(forward == back ? 0.0F : (forward ? 1.0F : -1.0F));
    }
}

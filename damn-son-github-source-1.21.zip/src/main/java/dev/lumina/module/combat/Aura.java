package dev.lumina.module.combat;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Aura extends Mod {
    private final Setting.Mode aim = add(new Setting.Mode("Aim Mode", "Select aim mode", "Smooth", "Snap", "None"));
    private final Setting.Num turn = add(new Setting.Num("Turn Speed", "Max degrees per tick", 55, 10, 180, 5));
    private final Setting.Num range = add(new Setting.Num("Attack Range", "Reach used for hits", 3.0, 1.0, 6.0, 0.1));
    private final Setting.Num search = add(new Setting.Num("Search Range", "Extra range for aiming", 1.5, 0.0, 4.0, 0.1));
    private final Setting.Bool players = add(new Setting.Bool("Players", "Target players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", "Target hostile mobs", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", "Target passive animals", false));
    private final Setting.Bool onlyCrits = add(new Setting.Bool("Only Crits", "Only critical hits", false));
    private final Setting.Bool smart = add(new Setting.Bool("Smart Crits", "Hit on ground when possible", true));
    private final Setting.Mode sprintReset = add(new Setting.Mode("Sprint Reset", "Reset sprint mode", "None", "Legit"));

    public Aura() {
        super("Aura", "Attacks nearby targets", Category.COMBAT);
        turn.visible = () -> aim.is("Smooth");
        smart.visible = () -> onlyCrits.value;
    }

    @Override public String suffix() { return aim.get(); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        double reach = range.value + search.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (!Targets.valid(le, players.value, mobs.value, animals.value)) continue;
            double d = Targets.distance(le);
            if (d <= reach && d < best) {
                best = d;
                target = le;
            }
        }
        if (target == null) return;

        rotate(p, target);

        if (best > range.value) return;
        if (p.getAttackCooldownProgress(0.5f) < 0.93f) return;
        if (!Targets.critOk(onlyCrits.value, smart.value)) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        if (sprintReset.is("Legit")) p.setSprinting(false);
    }

    private void rotate(ClientPlayerEntity p, LivingEntity t) {
        if (aim.is("None")) return;
        Vec3d eye = p.getEyePos();
        Vec3d to = t.getBoundingBox().getCenter();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        float cy = p.getYaw(), cp = p.getPitch();
        float dyaw = MathHelper.wrapDegrees(yaw - cy);
        float dpitch = pitch - cp;
        if (aim.is("Snap")) {
            p.setYaw(cy + dyaw);
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        } else {
            float s = (float) turn.value;
            p.setYaw(cy + MathHelper.clamp(dyaw, -s, s));
            p.setPitch(MathHelper.clamp(cp + MathHelper.clamp(dpitch, -s, s), -90f, 90f));
        }
    }
}

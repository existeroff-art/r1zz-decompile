package dev.lumina.module.combat;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Mod {
    private final Setting.Num health = add(new Setting.Num("Health", "Swap at or below (36 = always)", 36, 1, 36, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay", "Ticks between swaps", 2, 0, 10, 1));
    private int timer;

    public AutoTotem() {
        super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.value) return;

        ScreenHandler h = mc.player.playerScreenHandler;
        for (int i = 9; i <= 44; i++) {
            if (h.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                mc.interactionManager.clickSlot(h.syncId, i, 40, SlotActionType.SWAP, mc.player);
                timer = (int) delay.value;
                return;
            }
        }
    }
}

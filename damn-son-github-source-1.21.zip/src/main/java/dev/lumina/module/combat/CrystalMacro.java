package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.module.Targets;
import dev.lumina.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;

import java.util.List;

/**
 * CrystalMacro — auto crystal PVP.
 *
 * Each burst:
 *  1. Find nearest valid player target.
 *  2. Find a placement block adjacent to/under target (obsidian or bedrock).
 *  3. Switch to End Crystal in hotbar, right-click the block to place the crystal.
 *  4. Attack the placed crystal to explode it.
 *  5. Swap back to saved slot. Repeat after cooldown.
 *
 * PlaceDelay: ticks between placing and exploding (let physics register the crystal).
 * BurstDelay: ticks between full burst cycles.
 */
public class CrystalMacro extends Mod {
    private final Setting.Num placeRange  = add(new Setting.Num("Place Range", "Max distance to place crystal",  4.0, 1.0, 6.0, 0.5));
    private final Setting.Num explRange   = add(new Setting.Num("Expl Range",  "Max distance to explode crystal", 4.5, 1.0, 6.0, 0.5));
    private final Setting.Num placeDelay  = add(new Setting.Num("Place Delay", "Ticks between place and explode",  2, 1, 10, 1));
    private final Setting.Num burstDelay  = add(new Setting.Num("Burst Delay", "Ticks between burst cycles",       5, 1, 20, 1));
    private final Setting.Bool antiSelf   = add(new Setting.Bool("Anti-Self",  "Don't explode crystals close to you", true));
    private final Setting.Num selfRange   = add(new Setting.Num("Self Range",  "Min crystal-to-self distance",    2.0, 0.5, 4.0, 0.5));

    private int phaseTimer = 0;
    private int savedSlot  = -1;
    private boolean placed = false;
    private BlockPos lastPlacePos = null;
    private int spawnWaitTicks = 0;

    public CrystalMacro() {
        super("CrystalMacro", "Auto crystal PVP — place and explode", Category.COMBAT);
        selfRange.visible = () -> antiSelf.value;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        placed = false;
        phaseTimer = 0;
        lastPlacePos = null;
        spawnWaitTicks = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        phaseTimer--;
        if (phaseTimer > 0) return;

        if (!placed) {
            // Phase 1: find target + place crystal
            LivingEntity target = findTarget();
            if (target == null) return;

            int crystalSlot = findInHotbar(Items.END_CRYSTAL);
            if (crystalSlot < 0) return;

            BlockPos placePos = findPlacePos(target);
            if (placePos == null) return;

            savedSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = crystalSlot;

            // Right-click top face of the placement block
            Vec3d hitVec = Vec3d.ofCenter(placePos).add(0, 0.5, 0);
            BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, placePos, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);

            lastPlacePos = placePos.up(); // crystal spawns one block above the placed block
            placed = true;
            spawnWaitTicks = 0;
            phaseTimer = (int) placeDelay.value;
        } else {
            // Wait briefly for the server to spawn the crystal instead of giving up after
            // a single lookup. Only attack a crystal close to the block we just used.
            EndCrystalEntity crystal = findNearestCrystal(lastPlacePos);
            if (crystal == null && spawnWaitTicks++ < 6) {
                phaseTimer = 1;
                return;
            }
            if (crystal != null) {
                if (antiSelf.value && mc.player.distanceTo(crystal) < selfRange.value) {
                    finishBurst();
                    return;
                }
                mc.interactionManager.attackEntity(mc.player, crystal);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
            finishBurst();
        }
    }

    private void finishBurst() {
        placed = false;
        restoreSlot();
        phaseTimer = (int) burstDelay.value;
        lastPlacePos = null;
        spawnWaitTicks = 0;
    }

    private LivingEntity findTarget() {
        double maxR = placeRange.value + 1;
        LivingEntity best = null; double bestDist = maxR;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(maxR),
                le -> Targets.valid(le, true, false, false))) {
            double d = Targets.distance(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }

    private BlockPos findPlacePos(LivingEntity target) {
        BlockPos feet = target.getBlockPos();
        List<BlockPos> candidates = new java.util.ArrayList<>();
        candidates.add(feet.down());
        for (Direction dir : Direction.Type.HORIZONTAL) candidates.add(feet.down().offset(dir));
        // Prefer the closest valid base; the crystal needs two clear blocks above it and
        // must not intersect an entity. This was the main reason placement silently failed.
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos base : candidates) {
            var block = mc.world.getBlockState(base).getBlock();
            if (block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) continue;
            BlockPos spawn = base.up();
            if (!mc.world.getBlockState(spawn).isAir() || !mc.world.getBlockState(spawn.up()).isAir()) continue;
            double dist = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(spawn));
            if (dist > placeRange.value) continue;
            Box box = new Box(spawn.getX(), spawn.getY(), spawn.getZ(),
                    spawn.getX() + 1.0, spawn.getY() + 2.0, spawn.getZ() + 1.0);
            if (!mc.world.isSpaceEmpty(box)) continue;
            if (dist < bestDist) { bestDist = dist; best = base; }
        }
        return best;
    }

    private EndCrystalEntity findNearestCrystal(BlockPos expected) {
        Vec3d center = expected != null ? Vec3d.ofCenter(expected) : mc.player.getPos();
        double maxR = Math.min(explRange.value, 2.25);
        List<EndCrystalEntity> crystals = mc.world.getEntitiesByClass(
            EndCrystalEntity.class,
            new Box(center.x - maxR, center.y - maxR, center.z - maxR,
                    center.x + maxR, center.y + maxR + 2.0, center.z + maxR),
            e -> !e.isRemoved()
        );
        EndCrystalEntity best = null; double bestDist = maxR + 0.01;
        for (EndCrystalEntity c : crystals) {
            double d = c.getPos().distanceTo(center);
            if (d < bestDist) { bestDist = d; best = c; }
        }
        return best;
    }

    private int findInHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private void restoreSlot() {
        if (savedSlot >= 0 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
        }
    }
}

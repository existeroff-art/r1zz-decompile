package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import dev.lumina.mixin.LivingEntityAccessor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Client-side apple-use timer assist. Real multiplayer eating speed is still controlled
 * by the server; install the official Fast Gapple mod on the server as well where permitted.
 */
public class FastGApple extends Mod {
    private final Setting.Num acceleration = add(new Setting.Num(
            "Acceleration", "Extra client use ticks consumed per tick", 3, 1, 6, 1));

    public FastGApple() {
        super("Fast Gapple", "Golden-apple use timer assist (server support required)", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || !mc.player.isUsingItem()) return;
        ItemStack active = mc.player.getActiveItem();
        if (active.isEmpty() || (!active.isOf(Items.GOLDEN_APPLE)
                && !active.isOf(Items.ENCHANTED_GOLDEN_APPLE))) return;
        LivingEntityAccessor accessor = (LivingEntityAccessor) (Object) mc.player;
        int left = accessor.lumina$getItemUseTimeLeft();
        if (left > 1) accessor.lumina$setItemUseTimeLeft(Math.max(1, left - (int) acceleration.value));
    }
}

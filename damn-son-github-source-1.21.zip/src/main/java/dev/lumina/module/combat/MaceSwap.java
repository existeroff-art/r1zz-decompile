package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.item.Items;

/** Selects the mace while the player is descending, then restores the previous slot on landing. */
public class MaceSwap extends Mod {
    private final Setting.Num fallTrigger = add(new Setting.Num("Fall Trigger", "Swap when fall distance reaches", 1.5, 0.5, 6.0, 0.5));
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Restore the previous hotbar slot on landing", true));
    private int savedSlot = -1;

    public MaceSwap() { super("Mace Swap", "Automatically selects the mace during a falling hit", Category.COMBAT); }

    @Override public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (savedSlot >= 0) {
            if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()) {
                if (restore.value) mc.player.getInventory().selectedSlot = savedSlot;
                savedSlot = -1;
            }
            return;
        }
        if (mc.player.isOnGround() || mc.player.getVelocity().y >= -0.05 || mc.player.fallDistance < fallTrigger.value) return;
        int slot = findMace();
        if (slot < 0 || mc.player.getInventory().selectedSlot == slot) return;
        savedSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
    }

    @Override public void onDisable() {
        if (savedSlot >= 0 && mc.player != null && restore.value) mc.player.getInventory().selectedSlot = savedSlot;
        savedSlot = -1;
    }

    private int findMace() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        return -1;
    }
}

package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.item.Items;

/**
 * After a wind-charge stack is consumed from the selected slot, swaps to a hotbar mace.
 * This leaves aiming and using the wind charge to the player.
 */
public class MaceWindcharge extends Mod {
    private final Setting.Bool restore = add(new Setting.Bool("Restore Slot", "Restore wind-charge slot after landing", true));
    private int trackedSlot = -1;
    private int lastCount = -1;
    private int savedSlot = -1;
    private boolean tracking;

    public MaceWindcharge() {
        super("Mace Windcharge", "Switches to a mace immediately after using a wind charge", Category.COMBAT);
    }

    @Override public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (savedSlot >= 0) {
            if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()) {
                if (restore.value) mc.player.getInventory().selectedSlot = savedSlot;
                resetTracking();
            }
            return;
        }

        int selected = mc.player.getInventory().selectedSlot;
        var stack = mc.player.getInventory().getStack(selected);
        if (stack.isOf(Items.WIND_CHARGE)) {
            int count = stack.getCount();
            if (!tracking || trackedSlot != selected) {
                tracking = true;
                trackedSlot = selected;
                lastCount = count;
                return;
            }
            if (count < lastCount) {
                int maceSlot = findMace();
                if (maceSlot >= 0) {
                    savedSlot = trackedSlot;
                    mc.player.getInventory().selectedSlot = maceSlot;
                    tracking = false;
                } else {
                    resetTracking();
                }
            }
            lastCount = count;
        } else if (tracking && selected != trackedSlot) {
            // The user changed slots manually; do not override their choice.
            resetTracking();
        }
    }

    @Override public void onDisable() {
        if (savedSlot >= 0 && mc.player != null && restore.value) mc.player.getInventory().selectedSlot = savedSlot;
        resetTracking();
    }

    private int findMace() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        return -1;
    }

    private void resetTracking() {
        tracking = false;
        trackedSlot = -1;
        lastCount = -1;
        savedSlot = -1;
    }
}

package dev.lumina.module.combat;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import dev.lumina.setting.Setting;
import net.minecraft.item.*;

public class PvpMacros extends Mod {
    private final Setting.Bool wTap  = add(new Setting.Bool("W-Tap",  "Reset sprint after each hit for better KB", true));
    private final Setting.Num  ticks = add(new Setting.Num("Duration", "Ticks to hold the sprint-reset",           1, 1, 4, 1));

    private int    wTapTimer       = 0;
    private float  prevCooldown    = 1f;
    private boolean wasAttacking   = false;

    public PvpMacros() {
        super("PvP Macros", "Sprint-reset W-tap for better knockback", Category.COMBAT);
        ticks.visible = () -> wTap.value;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;

        float cool = mc.player.getAttackCooldownProgress(0.5f);

        // Detect moment player attacked: cooldown was at max → just reset to 0
        boolean justAttacked = prevCooldown >= 0.9f && cool < 0.1f;
        prevCooldown = cool;

        if (justAttacked && wTap.value && holdingWeapon()) {
            wTapTimer = (int) ticks.value;
        }

        if (wTapTimer > 0) {
            mc.player.setSprinting(false);
            wTapTimer--;
        }
    }

    @Override
    public void onDisable() {
        wTapTimer    = 0;
        prevCooldown = 1f;
    }

    private boolean holdingWeapon() {
        Item item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem
            || item instanceof AxeItem
            || item instanceof TridentItem
            || item instanceof MaceItem;
    }
}

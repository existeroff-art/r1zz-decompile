package dev.lumina.module.movement;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;

public class Fly extends Mod {
    private final Setting.Num speed = add(new Setting.Num("Speed", "Flight speed", 2.0, 0.5, 10.0, 0.5));

    public Fly() {
        super("Fly", "Creative-style flight", Category.MOVEMENT);
    }

    @Override public String suffix() { return "Creative"; }

    @Override
    public void onEnable() {
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying = true;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        p.getAbilities().allowFlying = true;
        p.getAbilities().setFlySpeed((float) (0.05 * speed.value));
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        p.getAbilities().setFlySpeed(0.05f);
        if (!p.isCreative() && !p.isSpectator()) {
            p.getAbilities().allowFlying = false;
            p.getAbilities().flying = false;
        }
    }
}

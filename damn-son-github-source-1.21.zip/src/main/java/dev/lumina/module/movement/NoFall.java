package dev.lumina.module.movement;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Mod {
    private final Setting.Num distance = add(new Setting.Num("Distance", "Fall distance before spoofing", 2.5, 1.0, 10.0, 0.5));

    public NoFall() {
        super("NoFall", "Cancels fall damage", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (mc.player.fallDistance > distance.value && !mc.player.getAbilities().flying) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
        }
    }
}

package dev.lumina.module.movement;

import dev.lumina.module.Category;
import dev.lumina.module.Mod;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/** Client-side SOCD priority: the last pressed opposing movement key wins. */
public class SnapTap extends Mod {
    private static volatile boolean active;
    private static long sequence;
    private static long leftOrder, rightOrder, forwardOrder, backOrder;

    public SnapTap() {
        super("Snap Tap", "Prioritizes the most recently pressed opposing movement key", Category.MOVEMENT);
    }

    @Override public void onEnable() { active = true; }
    @Override public void onDisable() { active = false; }

    public static boolean active() { return active; }

    public static void recordKey(int key, int scanCode, int action) {
        if (action != GLFW.GLFW_PRESS) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;
        KeyBinding left = client.options.leftKey;
        KeyBinding right = client.options.rightKey;
        KeyBinding forward = client.options.forwardKey;
        KeyBinding back = client.options.backKey;
        long order = ++sequence;
        if (left.matchesKey(key, scanCode)) leftOrder = order;
        if (right.matchesKey(key, scanCode)) rightOrder = order;
        if (forward.matchesKey(key, scanCode)) forwardOrder = order;
        if (back.matchesKey(key, scanCode)) backOrder = order;
    }

    public static boolean leftWins() { return leftOrder > rightOrder; }
    public static boolean forwardWins() { return forwardOrder > backOrder; }
}

package dev.lumina.module.player;

import dev.lumina.module.*;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoTool extends Mod {
    public AutoTool() {
        super("AutoTool", "Picks the fastest tool while mining", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.world.getBlockState(bhr.getBlockPos());
        int bestSlot = mc.player.getInventory().selectedSlot;
        float best = mc.player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            float sp = s.getMiningSpeedMultiplier(state);
            if (sp > best + 0.01f) {
                best = sp;
                bestSlot = i;
            }
        }
        mc.player.getInventory().selectedSlot = bestSlot;
    }
}

package dev.lumina.module.render;

import dev.lumina.module.*;
import dev.lumina.setting.Setting;

public class HudModule extends Mod {
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", "Info pill in the top-left", true));
    public final Setting.Bool arrayList = add(new Setting.Bool("Module List", "Enabled modules, top-right", true));
    public final Setting.Bool suffix = add(new Setting.Bool("Suffixes", "Show mode next to the name", true));
    public final Setting.Bool background = add(new Setting.Bool("List Background", "Dark pill behind entries", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates", "XYZ in the bottom-left", false));

    public HudModule() {
        super("HUD", "On-screen overlay", Category.RENDER);
        enabled = true;
        hudHidden = true;
        persistEnabled = true;
    }
}

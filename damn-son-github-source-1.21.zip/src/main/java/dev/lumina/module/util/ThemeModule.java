package dev.lumina.module.util;

import dev.lumina.module.*;
import dev.lumina.render.Theme;
import dev.lumina.setting.Setting;

public class ThemeModule extends Mod {
    private static final int[][] PALETTES = {
            {0xFF8B5CF6, 0xFFEC4899}, // Violet
            {0xFFEF4444, 0xFFF97316}, // Crimson
            {0xFF38BDF8, 0xFF6366F1}, // Ocean
            {0xFF34D399, 0xFF22D3EE}, // Emerald
            {0xFFF97316, 0xFFEC4899}, // Sunset
            {0xFFFB7185, 0xFFC084FC}  // Rose
    };

    public final Setting.Mode palette = add(new Setting.Mode("Accent", "Accent color palette",
            "Violet", "Crimson", "Ocean", "Emerald", "Sunset", "Rose"));
    public final Setting.Num opacity = add(new Setting.Num("Panel Opacity", "Glass panel transparency", 0.82, 0.4, 1.0, 0.02));

    public ThemeModule() {
        super("Theme", "Colors and glass settings", Category.UTIL);
        enabled = true;
        toggleable = false;
        hudHidden = true;
        persistEnabled = true;
        Theme.module = this;
    }

    public int c1() { return PALETTES[palette.index][0]; }
    public int c2() { return PALETTES[palette.index][1]; }
}

package dev.lumina.render;

import dev.lumina.module.util.ThemeModule;

public final class Theme {
    public static ThemeModule module;

    private Theme() {}

    public static int a1() { return module == null ? 0xFF8B5CF6 : module.c1(); }
    public static int a2() { return module == null ? 0xFFEC4899 : module.c2(); }

    /** Accent color that slowly drifts between the two palette colors. */
    public static int flow(double offset) {
        double t = (Math.sin(System.currentTimeMillis() / 1000.0 * 1.4 + offset) + 1.0) / 2.0;
        return Render2D.lerp(a1(), a2(), (float) t);
    }
}
